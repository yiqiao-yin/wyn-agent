

```python
api_key = "your_api_key_here"  # Replace with your actual API key
bot = ChatBot(api_key)
bot.run_mistral_agent()
```